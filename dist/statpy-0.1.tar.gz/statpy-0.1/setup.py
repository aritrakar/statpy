from setuptools import setup

setup(name='statpy',
      version='0.1',
      description='Gaussian and Binomial distributions (for Udacity AWS MLE Foundations course)',
      packages=['statpy'],
      zip_safe=False)
